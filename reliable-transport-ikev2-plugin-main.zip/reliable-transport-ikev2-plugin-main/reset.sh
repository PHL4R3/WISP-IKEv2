#!/bin/bash

if [ $EUID != 0 ]; then
	echo "Must be run as root";
else
	make
	sudo make install >/dev/null
	sudo systemctl daemon-reload >/dev/null
	sudo systemctl restart strongswan >/dev/null
	sudo systemctl status strongswan
fi
